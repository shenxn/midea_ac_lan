"""Midea lan CA message."""

from midealan.const import DeviceType
from midealan.message import (
    ListTypes,
    MessageBody,
    MessageRequest,
    MessageResponse,
    MessageType,
    ToshibaFrame,
)

MIN_CA_GENERAL_BODY_LENGTH = 20
CA_GENERAL_BODY_LENGTH1 = 25
CA_GENERAL_BODY_LENGTH2 = 30
CA_GENERAL_BODY_LENGTH3 = 31
TEMP_POS_LOWER_VALUE = 1
TEMP_POS_UPPER_VALUE = 29
TEMP_NEG_LOWER_VALUE = 49
TEMP_NEG_UPPER_VALUE = 54

# Toshiba CA base-status layouts.
# Some Japanese CA firmware returns the query response as wire bytes 03 80.
# Keep the complete discriminator so unrelated high-byte values remain rejected.
TOSHIBA_CA_QUERY_RESPONSE = 0x8003
TOSHIBA_CA_RESPONSE_FRAME_TYPES = frozenset(
    (MessageType.query, MessageType.notify1, TOSHIBA_CA_QUERY_RESPONSE),
)
TOSHIBA_CA_BASE_BODY_TYPE = 0x00
TOSHIBA_CA_BASE_STATUS_LENGTH = 13
TOSHIBA_CA_SHIFTED_BASE_STATUS_LENGTH = 16
TOSHIBA_CA_POWER_FLAGS_OFFSET = 1
TOSHIBA_CA_NORMAL_MODE_OFFSET = 2
TOSHIBA_CA_NORMAL_DOOR_OFFSET = 8
TOSHIBA_CA_NORMAL_ENERGY_OFFSET = 11
TOSHIBA_CA_SHIFTED_MODE_OFFSET = 4
TOSHIBA_CA_SHIFTED_DOOR_OFFSET = 11
TOSHIBA_CA_SHIFTED_ENERGY_OFFSET = 14
TOSHIBA_CA_ENERGY_WIDTH = 2

# Toshiba CA status masks.
TOSHIBA_CA_POWER_SAVING_MASK = 0x01
TOSHIBA_CA_REFRIGERATOR_DOOR_MASK = 0x01
TOSHIBA_CA_FREEZER_DOOR_MASK = 0x02
TOSHIBA_CA_BAR_DOOR_MASK = 0x04
TOSHIBA_CA_FLEX_ZONE_DOOR_MASK = 0x08


ToshibaCAStatus = dict[str, bool | int]


def decode_toshiba_ca_status(
    frame: ToshibaFrame,
    *,
    shifted: bool,
) -> ToshibaCAStatus | None:
    """Decode a complete Toshiba CA base status."""
    body = frame.body
    minimum_length = (
        TOSHIBA_CA_SHIFTED_BASE_STATUS_LENGTH
        if shifted
        else TOSHIBA_CA_BASE_STATUS_LENGTH
    )
    if (
        frame.frame_type not in TOSHIBA_CA_RESPONSE_FRAME_TYPES
        or len(body) < minimum_length
        or body[0] != TOSHIBA_CA_BASE_BODY_TYPE
    ):
        return None

    if shifted:
        mode_offset = TOSHIBA_CA_SHIFTED_MODE_OFFSET
        door_offset = TOSHIBA_CA_SHIFTED_DOOR_OFFSET
        energy_offset = TOSHIBA_CA_SHIFTED_ENERGY_OFFSET
    else:
        mode_offset = TOSHIBA_CA_NORMAL_MODE_OFFSET
        door_offset = TOSHIBA_CA_NORMAL_DOOR_OFFSET
        energy_offset = TOSHIBA_CA_NORMAL_ENERGY_OFFSET
    door_flags = body[door_offset]
    return {
        "mode": body[mode_offset],
        "energy_saving_mode": bool(
            body[TOSHIBA_CA_POWER_FLAGS_OFFSET] & TOSHIBA_CA_POWER_SAVING_MASK,
        ),
        "refrigerator_actual_temp": body[mode_offset + 1],
        "freezer_actual_temp": body[mode_offset + 2],
        "refrigerator_door": bool(
            door_flags & TOSHIBA_CA_REFRIGERATOR_DOOR_MASK,
        ),
        "freezer_door": bool(door_flags & TOSHIBA_CA_FREEZER_DOOR_MASK),
        "bar_door": bool(door_flags & TOSHIBA_CA_BAR_DOOR_MASK),
        "flex_zone_door": bool(door_flags & TOSHIBA_CA_FLEX_ZONE_DOOR_MASK),
        "energy_consumption": int.from_bytes(
            body[energy_offset : energy_offset + TOSHIBA_CA_ENERGY_WIDTH],
            "little",
        ),
    }


class MessageCABase(MessageRequest):
    """CA message base."""

    def __init__(
        self,
        protocol_version: int,
        message_type: MessageType,
        body_type: ListTypes,
    ) -> None:
        """Initialize CA message base."""
        super().__init__(
            device_type=DeviceType.CA,
            protocol_version=protocol_version,
            message_type=message_type,
            body_type=body_type,
        )

    @property
    def _body(self) -> bytearray:
        raise NotImplementedError


class MessageQuery(MessageCABase):
    """CA message query."""

    def __init__(self, protocol_version: int) -> None:
        """Initialize CA message query."""
        super().__init__(
            protocol_version=protocol_version,
            message_type=MessageType.query,
            body_type=ListTypes.X00,
        )

    @property
    def _body(self) -> bytearray:
        return bytearray([])


class CAGeneralMessageBody(MessageBody):
    """CA message general body."""

    def __init__(self, body: bytearray) -> None:
        """Initialize CA message general body."""
        super().__init__(body)

        self.code_mode = (body[1] & 0x01) > 0
        self.freezing_mode = (body[1] & 0x02) > 0
        self.smart_mode = (body[1] & 0x04) > 0
        self.energy_saving_mode = (body[1] & 0x08) > 0
        self.holiday_mode = (body[1] & 0x10) > 0
        self.moisturize_mode = (body[1] & 0x20) > 0
        self.preservation_mode = (body[1] & 0x40) > 0
        self.acme_freezing_mode = (body[1] & 0x80) > 0
        # Keep the historical parser name for callers using it directly.
        self.acmeFreezing_mode = self.acme_freezing_mode
        # refrigerationTemperature
        self.refrigerator_setting_temp = body[2] & 0x0F
        # freezingTemperature
        self.freezer_setting_temp = -12 - ((body[2] & 0xF0) >> 4)
        # lVariableTemperature
        flex_zone_setting_temp = body[3]
        # rVariableTemperature
        right_flex_zone_setting_temp = body[4]

        if TEMP_POS_LOWER_VALUE <= flex_zone_setting_temp <= TEMP_POS_UPPER_VALUE:
            self.flex_zone_setting_temp = flex_zone_setting_temp - 19
        elif TEMP_NEG_LOWER_VALUE <= flex_zone_setting_temp <= TEMP_NEG_UPPER_VALUE:
            self.flex_zone_setting_temp = 30 - flex_zone_setting_temp
        else:
            self.flex_zone_setting_temp = 0
        if TEMP_POS_LOWER_VALUE <= right_flex_zone_setting_temp <= TEMP_POS_UPPER_VALUE:
            self.right_flex_zone_setting_temp = right_flex_zone_setting_temp - 19
        elif (
            TEMP_NEG_LOWER_VALUE <= right_flex_zone_setting_temp <= TEMP_NEG_UPPER_VALUE
        ):
            self.right_flex_zone_setting_temp = 30 - right_flex_zone_setting_temp
        else:
            self.right_flex_zone_setting_temp = 0

        self.variable_mode = body[5]  # variableModeValue
        # *powerValue 0x00 is on, 0x04/0x08/0x10/20 is off
        self.refrigeration_power = (body[6] & 0x01) < 1  # refrigerationPowerValue
        self.l_variable_power = (body[6] & 0x04) < 1  # lVariablePowerValue
        self.r_variable_power = (body[6] & 0x08) < 1  # rVariablePowerValue
        self.freezing_power = (body[6] & 0x10) < 1  # freezingPowerValue
        self.cross_peak_electricity_enter = body[6] & 0x20  # crossPeakElectricityEnter
        self.cross_peak_electricity = (body[6] & 0x40) > 0  # crossPeakElectricity
        self.all_refrigeration_power = (body[6] & 0x80) > 0  # allRefrigerationPower
        self.remove_dew = body[7] & 0x01  # removeDew
        self.humidify = body[7] & 0x02  # humidify
        self.unfreeze = body[7] & 0x04  # unfreeze
        # 0x08 fahrenheit, 0x00 celsius
        self.temperature_unit = body[7] & 0x08  # temperatureUnit
        self.flood_light = body[7] & 0x10  # floodlight
        # functionSwitch for icea_bar_function_switch
        self.function_switch = body[7] & 0xC0  # functionSwitch
        self.radar_mode = body[8] & 0x01  # radarMode
        self.milk_mode = body[8] & 0x02  # milkMode
        self.iced_mode = body[8] & 0x04  # icedMode
        self.plasma_aseptic_mode = body[8] & 0x08  # plasmaAsepticMode
        self.acquire_icea_mode = body[8] & 0x10  # acquireIceaMode
        self.brash_icea_mode = body[8] & 0x20  # brashIceaMode
        self.acquire_water_mode = body[8] & 0x40  # acquireWaterMode
        self.freezing_ice_machine_power = body[8] & 0x80  # freezingIceMachinePower
        self.freezing_fahrenheit = body[9]  # freezingFahrenheit
        self.refrigeration_fahrenheit = body[10] & 0xFC  # refrigerationFahrenheit
        self.leach_expire_day = body[11]  # leachExpireDay

        # powerConsumptionLow & powerConsumptionHigh
        self.energy_consumption = (body[13] << 8) + body[12]

        self.freezing_motor_reset_status = body[14] & 0x01  # freezingMotorResetStatus
        self.freezing_motor_deicing_status = (
            body[14] & 0x02
        )  # freezingMotorDeicingStatus
        self.freezing_ice_machine_water_status = (
            body[14] & 0x04
        )  # freezingIceMachineWaterStatus
        self.freezing_all_ice_status = body[14] & 0x08  # freezingAllIceStatus
        self.human_induction = body[14] & 0x10  # humanInduction
        self.refrigeration_door_power = body[15] & 0x01  # refrigerationDoorPower
        self.freezing_door_power = body[15] & 0x02  # freezingDoorPower
        self.variable_door_power = body[15] & 0x10  # variableDoorPower
        self.storage_iceHome_door_state = body[15] & 0x20  # storageIceHomeDoorState
        self.bar_door_power = body[15] & 0x04  # barDoorPower
        self.ice_mouth_power = body[15] & 0x08  # iceMouthPower
        self.is_error = body[16] & 0x01  # isError
        self.interval_room_humidity_level = body[16] & 0xFE  # intervalRoomHumidityLevel

        # refrigerationRealTemperature
        self.refrigerator_actual_temp = (body[17] - 100) / 2
        # freezingRealTemperature
        self.freezer_actual_temp = (body[18] - 100) / 2
        # lVariableRealTemperature
        self.flex_zone_actual_temp = (body[19] - 100) / 2
        # rVariableRealTemperature
        self.right_flex_zone_actual_temp = (body[20] - 100) / 2

        # fastColdMinuteLow & fastColdMinuteHigh
        self.fast_cold_minute = (body[22] << 8) + body[21]
        # fastFreezeMinuteLow & fastFreezeMinuteHigh
        self.fast_freeze_minute = (body[24] << 8) + body[23]

        if len(body) > CA_GENERAL_BODY_LENGTH1:
            self.microcrystal_fresh = (body[27] & 0x01) > 0
            self.dry_zone = (body[27] & 0x02) > 0
            self.electronic_smell = (body[27] & 0x04) > 0
            self.humidity = body[27] & 0x70
            self.normal_temperature_level = body[28]
            self.function_zone_level = body[29]

        if len(body) > CA_GENERAL_BODY_LENGTH2:
            self.humidity_setting = body[30] & 0x7F
            self.smart_humidity = body[30] & 0x80

        if len(body) > CA_GENERAL_BODY_LENGTH3:
            self.storage_left_door_auto = body[31] & 0x03
            self.storage_right_door_auto = body[31] & 0x0C
            self.freezer_door_auto = body[31] & 0x30
            self.freezer_door_auto_control = body[31] & 0x40
            self.storage_door_auto_control = body[31] & 0x80


class CAExceptionMessageBody(MessageBody):
    """CA message exception body."""

    def __init__(self, body: bytearray) -> None:
        """Initialize CA message exception body."""
        super().__init__(body)

        self.refrigerator_door_overtime = (body[1] & 0x01) > 0
        self.freezer_door_overtime = (body[1] & 0x02) > 0
        self.bar_door_overtime = (body[1] & 0x04) > 0
        self.flex_zone_door_overtime = (body[1] & 0x08) > 0

        self.ice_miachine_full = body[1] & 0x10
        self.refrigeration_sensor_error = body[2] & 0x01
        self.refrigeration_deforsting_sensor_error = body[2] & 0x02
        self.ring_temperature_sensor_error = body[2] & 0x04
        self.flex_zone_sensor_error = body[2] & 0x08
        self.right_flex_zone_sensor_error = body[2] & 0x10
        self.freezing_high_temperature = body[2] & 0x20
        self.freezing_sensor_error = body[2] & 0x40
        self.freezing_defrosting_sensor_error = body[2] & 0x80
        self.ice_electrical_machinery_error = body[3] & 0x01
        self.refrigeration_defrosting_overtime = body[3] & 0x02
        self.freezing_defrosting_overtime = body[3] & 0x04
        self.zeroCrossingCheckError = body[3] & 0x08
        self.eepromReadWriteError = body[3] & 0x04
        self.leftFlexzoneSensorError = body[3] & 0x04
        self.iceRoomSensorError = body[3] & 0x04
        self.mainDisplayCorrespondError = body[3] & 0x04
        self.flexzoneDefrostingSensorError = body[3] & 0x04
        self.flexzoneDefrostingSensor2Error = body[3] & 0x04
        self.yogurtMachineSensorError = body[3] & 0x04
        self.iceMachineFrettingSwitchError = body[3] & 0x04
        self.iceMachinePipeFilterOvertime = body[3] & 0x04
        self.ambientHumiditySensorError = body[3] & 0x04
        self.storageHumiditySensorError = body[3] & 0x04
        self.radarSensor1Error = body[3] & 0x04
        self.radarSensor2Error = body[3] & 0x04
        self.radarSensor3Error = body[3] & 0x04
        self.radarSensor4Error = body[3] & 0x04
        self.radarSensor5Error = body[3] & 0x04
        self.functionZoneTemperatureSensorError = body[3] & 0x04
        self.normalZoneTemperatureSensorError = body[3] & 0x04
        self.humidityControlSensorError = body[3] & 0x04
        self.openDoorTooFrequently = body[3] & 0x04
        self.storageDoorAloneOpenFrequently = body[3] & 0x04
        self.freezingDoorAloneOpenFrequently = body[3] & 0x04
        self.barDoorAloneOpenFrequently = body[3] & 0x04
        self.storageTemperatureOverheating = body[3] & 0x04
        self.storageTemperatureTooLow = body[3] & 0x04
        self.storageHeatingWireSensorError = body[3] & 0x04
        self.storageTemperatureTooLow = body[3] & 0x04


class CANotify00MessageBody(MessageBody):
    """CA message notify00 body."""

    def __init__(self, body: bytearray) -> None:
        """Initialize CA message notify00 body."""
        super().__init__(body)
        self.refrigerator_door = (body[1] & 0x01) > 0
        self.freezer_door = (body[1] & 0x02) > 0
        self.bar_door = (body[1] & 0x04) > 0
        self.flex_zone_door = (body[1] & 0x010) > 0


class CANotify01MessageBody(MessageBody):
    """CA message notify01 body."""

    def __init__(self, body: bytearray) -> None:
        """Initialize CA message notify01 body."""
        super().__init__(body)
        self.refrigerator_setting_temp = body[37]
        self.freezer_setting_temp = -12 - body[38]
        flex_zone_setting_temp = body[39]
        right_flex_zone_setting_temp = body[40]

        if TEMP_POS_LOWER_VALUE <= flex_zone_setting_temp <= TEMP_POS_UPPER_VALUE:
            self.flex_zone_setting_temp = flex_zone_setting_temp - 19
        elif TEMP_NEG_LOWER_VALUE <= flex_zone_setting_temp <= TEMP_NEG_UPPER_VALUE:
            self.flex_zone_setting_temp = 30 - flex_zone_setting_temp
        else:
            self.flex_zone_setting_temp = 0
        if TEMP_POS_LOWER_VALUE <= right_flex_zone_setting_temp <= TEMP_POS_UPPER_VALUE:
            self.right_flex_zone_setting_temp = right_flex_zone_setting_temp - 19
        elif (
            TEMP_NEG_LOWER_VALUE <= right_flex_zone_setting_temp <= TEMP_NEG_UPPER_VALUE
        ):
            self.right_flex_zone_setting_temp = 30 - right_flex_zone_setting_temp
        else:
            self.right_flex_zone_setting_temp = 0


class MessageCAResponse(MessageResponse):
    """CA message response."""

    def __init__(self, message: bytes) -> None:
        """Initialize CA message response."""
        super().__init__(bytearray(message))
        # uptable["dataType"] 0x02 and messageBytes[0] 0x00
        # uptable["dataType"] 0x03 and messageBytes[0] 0x00
        # uptable["dataType"] 0x04 and messageBytes[0] 0x02)
        if (
            (
                self.message_type in [MessageType.query, MessageType.set]
                and self.body_type == ListTypes.X00
            )
            or (
                self.message_type == MessageType.notify1
                and self.body_type == ListTypes.X02
            )
        ) and len(super().body) > MIN_CA_GENERAL_BODY_LENGTH:
            self.set_body(CAGeneralMessageBody(super().body))
        # uptable["dataType"] 0x06 and messageBytes[0] 0x01
        # uptable["dataType"] 0x03 and messageBytes[0] 0x02
        elif (
            self.message_type == MessageType.exception
            and self.body_type == ListTypes.X01
        ) or (
            self.message_type == MessageType.query and self.body_type == ListTypes.X02
        ):
            self.set_body(CAExceptionMessageBody(super().body))
        # uptable["dataType"] 0x04 and messageBytes[0] 0x00
        elif (
            self.message_type == MessageType.notify1 and self.body_type == ListTypes.X00
        ):
            self.set_body(CANotify00MessageBody(super().body))
        # uptable["dataType"] 0x04 and messageBytes[0] 0x01
        # uptable["dataType"] 0x03 and messageBytes[0] 0x01
        elif (
            self.message_type in [MessageType.query, MessageType.notify1]
            and self.body_type == ListTypes.X01
        ):
            self.set_body(CANotify01MessageBody(super().body))
        self.set_attr()


# Exact GR-A540XFS profile: T_0008_2600_CA_10.lua, base body Data0..92.
# Kept separate from the older CA layouts: temperature bytes are levels,
# instantaneous_power/daily_energy are big-endian, not cumulative energy.
AXFS_MODEL = "00000003"
AXFS_SUBTYPE = 38
AXFS_BODY_LENGTH = 93
AXFS_UNCHANGED = 0xFF
AXFS_LEVEL_STEP = 5
AXFS_LEVEL_MAX = 24
AXFS_LEVEL_COUNT = 5
AXFS_MAX_HOUR = 23
AXFS_MAX_MINUTE = 59
AXFS_TIME_STRING_LENGTH = 5
AXFS_UV_OFFSET = 8
AXFS_ENUM_FIELDS = {
    "chilled_const": (1, {0: "normal", 1: "power_low_temp", 2: "deli_chilled"}),
    "chilled_temp": (1, {0: "not_set", 1: "chilled", 2: "thawing"}),
    "power_saving_mode": (
        3,
        {
            0: "normal",
            1: "power_saving_auto",
            2: "power_saving_auto_plus",
            3: "power_saving",
            4: "low_power_cooling",
        },
    ),
    "cooling": (
        4,
        {
            0: "normal",
            1: "quick_freezing",
            6: "rough_heat_removal",
            7: "cool_cooking",
            8: "timer",
            9: "frozen_rice",
        },
    ),
    "ice_making": (7, {0: "normal", 1: "quick", 2: "off"}),
}
AXFS_SWITCH_FIELDS = {
    "vegetable_sterilization": (8, 0),
    "night_mode": (21, 0),
    "auto_door_left": (21, 1),
    "auto_door_right": (21, 2),
    "light_blue_led": (21, 3),
}
AXFS_NUMBER_FIELDS = {
    "ceiling_light_normal": (22, 100),
    "door_light_normal": (23, 100),
    "chilled_light_normal": (24, 100),
    "vege_light_normal": (25, 100),
    "ceiling_light_night": (26, 100),
    "door_light_night": (27, 100),
    "chilled_light_night": (28, 100),
    "vege_light_night": (29, 100),
    "night_start_min": (30, 59),
    "night_start_hour": (31, 23),
    "night_end_min": (32, 59),
    "night_end_hour": (33, 23),
}
AXFS_LEVEL_FIELDS = {"refrigerator_level": 5, "freezer_level": 6}
AXFS_DOOR_FIELDS = {
    "refrigerator_door": 0,
    "freezer_door": 1,
    "ice_door": 2,
    "vegetable_door": 3,
    "upper_freezer_door": 4,
}
AXFS_LIGHT_PRESETS = {
    "dim": (18, 25, 12, 12),
    "medium": (40, 62, 25, 25),
    "standard": (100, 100, 100, 100),
}
AXFS_DOOR_STRENGTHS = {
    "auto_door_left_strength": (
        34,
        ((45, 53, 53), (50, 59, 59), (55, 65, 65), (57, 71, 71), (60, 99, 99)),
    ),
    "auto_door_right_strength": (
        37,
        ((30, 35, 35), (32, 42, 42), (35, 50, 50), (42, 57, 57), (50, 99, 99)),
    ),
}
AXFS_TELEMETRY = (
    "ice_making_status",
    "ice_tray_cleaning",
    "defrost_moisture",
    "defrost_precool",
    "defrost_active",
    "estimated_power",
    "energy_last_24h",
    "error_code",
    "ambient_temperature",
    "cooling_timer",
    "weekly_reminder",
    "weekly_reminder_hour",
    "weekly_reminder_min",
)
AXFS_ATTRIBUTES = frozenset(
    (
        *AXFS_ENUM_FIELDS,
        *AXFS_SWITCH_FIELDS,
        *AXFS_NUMBER_FIELDS,
        *AXFS_LEVEL_FIELDS,
        *AXFS_DOOR_FIELDS,
        *AXFS_DOOR_STRENGTHS,
        *AXFS_TELEMETRY,
        "lighting",
    ),
)


def decode_axfs_status(
    frame: ToshibaFrame,
) -> dict[str, bool | int | float | str | None] | None:
    """Decode only the complete exact-model base status; retain unknowns."""
    body = frame.body
    if (
        frame.frame_type not in TOSHIBA_CA_RESPONSE_FRAME_TYPES
        or len(body) != AXFS_BODY_LENGTH
        or body[0] != 0
    ):
        return None
    status: dict[str, bool | int | float | str | None] = {}
    for name, (offset, options) in AXFS_ENUM_FIELDS.items():
        value = body[offset]
        if name in {"chilled_const", "ice_making"}:
            value &= 0x0F
        elif name == "chilled_temp":
            value >>= 4
        status[name] = options.get(value)
    for name, (offset, bit) in AXFS_SWITCH_FIELDS.items():
        status[name] = bool(body[offset] & (1 << bit))
    for name, (offset, maximum) in AXFS_NUMBER_FIELDS.items():
        status[name] = body[offset] if body[offset] <= maximum else None
    for name, offset in AXFS_LEVEL_FIELDS.items():
        status[name] = (
            body[offset] // AXFS_LEVEL_STEP + 1
            if body[offset] <= AXFS_LEVEL_MAX
            else None
        )
    for name, bit in AXFS_DOOR_FIELDS.items():
        status[name] = bool(body[11] & (1 << bit))
    for name, (offset, presets) in AXFS_DOOR_STRENGTHS.items():
        values = tuple(body[offset : offset + 3])
        status[name] = next(
            (i for i, preset in enumerate(presets, 1) if values == preset),
            None,
        )
    status["lighting"] = next(
        (
            name
            for name, preset in AXFS_LIGHT_PRESETS.items()
            if tuple(body[22:26]) == preset
        ),
        None,
    )
    status.update(
        {
            "ice_making_status": {
                0: "running",
                1: "water_shortage",
                2: "ice_full",
                3: "stop",
            }.get(body[7] >> 4),
            "ice_tray_cleaning": bool(body[8] & 2),
            "defrost_moisture": bool(body[10] & 1),
            "defrost_precool": bool(body[10] & 2),
            "defrost_active": bool(body[10] & 4),
            "estimated_power": int.from_bytes(body[12:14], "big"),
            "energy_last_24h": int.from_bytes(body[14:16], "big"),
            "error_code": None
            if body[16:18] == b"\xff\xff"
            else int.from_bytes(body[16:18], "little"),
            "ambient_temperature": None
            if body[18:20] == b"\xff\xff"
            else int.from_bytes(body[18:20], "little", signed=True) / 10,
            "cooling_timer": None if body[20] == AXFS_UNCHANGED else body[20],
            "weekly_reminder": bool(body[40] & 1),
            "weekly_reminder_min": body[41] if body[41] <= AXFS_MAX_MINUTE else None,
            "weekly_reminder_hour": body[42] if body[42] <= AXFS_MAX_HOUR else None,
        },
    )
    return status


def axfs_control_body(attr: str, value: bool | float | str) -> bytes:
    """Encode one validated setting with vendor-defined preservation masks.

    No reset, service, door actuation, ice cleaning, or synthetic notices.
    All unspecified bytes retain 0xFF except ice_making's 0x0F sentinel.
    """
    body = bytearray([AXFS_UNCHANGED] * AXFS_BODY_LENGTH)
    body[0] = 0
    body[7] = 0x0F
    if attr in AXFS_ENUM_FIELDS:
        offset, options = AXFS_ENUM_FIELDS[attr]
        inverse = {name: code for code, name in options.items()}
        if not isinstance(value, str) or value not in inverse:
            raise ValueError("Invalid refrigerator mode")
        code = inverse[value]
        body[offset] = (
            (0xF0 | code)
            if attr == "chilled_const"
            else ((code << 4) | 0x0F)
            if attr == "chilled_temp"
            else code
        )
    elif attr in AXFS_SWITCH_FIELDS:
        if not isinstance(value, bool):
            raise ValueError("Refrigerator switches require booleans")
        offset, bit = AXFS_SWITCH_FIELDS[attr]
        # Data8 preserves unused bits and cleaning; Data21 uses mask bits4..7.
        body[offset] = (
            (0xFC if offset == AXFS_UV_OFFSET else 0xF0) & ~(1 << (bit + 4))
        ) | (int(value) << bit)
    elif (
        attr in AXFS_LEVEL_FIELDS
        or attr in AXFS_NUMBER_FIELDS
        or attr in AXFS_DOOR_STRENGTHS
    ):
        if (
            isinstance(value, bool)
            or not isinstance(value, (int, float))
            or not float(value).is_integer()
        ):
            raise ValueError("Refrigerator settings require whole numbers")
        number = int(value)
        if attr in AXFS_LEVEL_FIELDS or attr in AXFS_DOOR_STRENGTHS:
            if not 1 <= number <= AXFS_LEVEL_COUNT:
                raise ValueError("Refrigerator level must be 1..5")
            if attr in AXFS_LEVEL_FIELDS:
                body[AXFS_LEVEL_FIELDS[attr]] = (number - 1) * AXFS_LEVEL_STEP + 2
            else:
                offset, presets = AXFS_DOOR_STRENGTHS[attr]
                body[offset : offset + 3] = bytes(presets[number - 1])
        else:
            offset, maximum = AXFS_NUMBER_FIELDS[attr]
            if not 0 <= number <= maximum:
                raise ValueError("Refrigerator setting outside allowed range")
            body[offset] = number
    elif attr == "lighting":
        if not isinstance(value, str) or value not in AXFS_LIGHT_PRESETS:
            raise ValueError("Invalid refrigerator lighting preset")
        body[22:26] = bytes(AXFS_LIGHT_PRESETS[value])
    elif attr in {"night_start", "night_end"}:
        if (
            not isinstance(value, str)
            or len(value) != AXFS_TIME_STRING_LENGTH
            or value[2] != ":"
            or not (value[:2] + value[3:]).isascii()
            or not (value[:2] + value[3:]).isdigit()
        ):
            raise ValueError("Night time must use HH:MM")
        hour, minute = int(value[:2]), int(value[3:])
        if hour > AXFS_MAX_HOUR or minute > AXFS_MAX_MINUTE:
            raise ValueError("Night time outside allowed range")
        offset = 30 if attr == "night_start" else 32
        body[offset : offset + 2] = bytes((minute, hour))
    else:
        raise ValueError("Unsupported refrigerator control")
    return bytes(body)
