"""Midea lan CA device."""

import logging
from enum import StrEnum
from typing import Any, ClassVar, Unpack

from midealan.const import DeviceType
from midealan.device import MideaDevice, MideaDeviceInitKwargs
from midealan.message import (
    MessageRequest,
    MessageType,
    ToshibaFrame,
    ToshibaMessageRequest,
)

from .message import (
    AXFS_ATTRIBUTES,
    AXFS_MODEL,
    AXFS_SUBTYPE,
    TOSHIBA_CA_RESPONSE_FRAME_TYPES,
    MessageCAResponse,
    MessageQuery,
    axfs_control_body,
    decode_axfs_status,
    decode_toshiba_ca_status,
)

_LOGGER = logging.getLogger(__name__)

SUBTYPE_310A2111 = 56
TOSHIBA_SHIFTED_MODEL = "0000000D"
FLEX_ZONE_MODE_BY_TEMPERATURE: dict[float, str] = {
    6.0: "baby",
    2.0: "treasure",
    0.0: "zero",
}


class DeviceAttributes(StrEnum):
    """Midea CA device attributes."""

    mode = "mode"
    code_mode = "code_mode"
    freezing_mode = "freezing_mode"
    smart_mode = "smart_mode"
    energy_saving_mode = "energy_saving_mode"
    holiday_mode = "holiday_mode"
    moisturize_mode = "moisturize_mode"
    preservation_mode = "preservation_mode"
    acme_freezing_mode = "acme_freezing_mode"
    flood_light = "flood_light"
    freezing_ice_machine_power = "freezing_ice_machine_power"
    energy_consumption = "energy_consumption"
    refrigerator_actual_temp = "refrigerator_actual_temp"
    freezer_actual_temp = "freezer_actual_temp"
    flex_zone_actual_temp = "flex_zone_actual_temp"
    right_flex_zone_actual_temp = "right_flex_zone_actual_temp"
    refrigerator_setting_temp = "refrigerator_setting_temp"
    freezer_setting_temp = "freezer_setting_temp"
    flex_zone_setting_temp = "flex_zone_setting_temp"
    right_flex_zone_setting_temp = "right_flex_zone_setting_temp"
    refrigerator_door_overtime = "refrigerator_door_overtime"
    freezer_door_overtime = "freezer_door_overtime"
    bar_door_overtime = "bar_door_overtime"
    flex_zone_door_overtime = "flex_zone_door_overtime"
    refrigerator_door = "refrigerator_door"
    freezer_door = "freezer_door"
    bar_door = "bar_door"
    flex_zone_door = "flex_zone_door"
    microcrystal_fresh = "microcrystal_fresh"
    electronic_smell = "electronic_smell"
    humidity = "humidity"
    variable_mode = "variable_mode"

    ambient_temperature = "ambient_temperature"
    auto_door_left = "auto_door_left"
    auto_door_left_strength = "auto_door_left_strength"
    auto_door_right = "auto_door_right"
    auto_door_right_strength = "auto_door_right_strength"
    ceiling_light_night = "ceiling_light_night"
    ceiling_light_normal = "ceiling_light_normal"
    chilled_const = "chilled_const"
    chilled_light_night = "chilled_light_night"
    chilled_light_normal = "chilled_light_normal"
    chilled_temp = "chilled_temp"
    cooling = "cooling"
    cooling_timer = "cooling_timer"
    defrost_active = "defrost_active"
    defrost_moisture = "defrost_moisture"
    defrost_precool = "defrost_precool"
    door_light_night = "door_light_night"
    door_light_normal = "door_light_normal"
    energy_last_24h = "energy_last_24h"
    error_code = "error_code"
    estimated_power = "estimated_power"
    freezer_level = "freezer_level"
    ice_door = "ice_door"
    ice_making = "ice_making"
    ice_making_status = "ice_making_status"
    ice_tray_cleaning = "ice_tray_cleaning"
    light_blue_led = "light_blue_led"
    lighting = "lighting"
    night_end_hour = "night_end_hour"
    night_end_min = "night_end_min"
    night_mode = "night_mode"
    night_start_hour = "night_start_hour"
    night_start_min = "night_start_min"
    power_saving_mode = "power_saving_mode"
    refrigerator_level = "refrigerator_level"
    upper_freezer_door = "upper_freezer_door"
    vege_light_night = "vege_light_night"
    vege_light_normal = "vege_light_normal"
    vegetable_door = "vegetable_door"
    vegetable_sterilization = "vegetable_sterilization"
    weekly_reminder = "weekly_reminder"
    weekly_reminder_hour = "weekly_reminder_hour"
    weekly_reminder_min = "weekly_reminder_min"


class MideaCADevice(MideaDevice):
    """Midea CA device."""

    TOSHIBA_SUPPORTED = True
    TOSHIBA_RESPONSE_FRAME_TYPES = TOSHIBA_CA_RESPONSE_FRAME_TYPES

    _variable_mode: ClassVar[dict[int, str]] = {
        0x00: "none",
        0x01: "soft_freezing",
        0x02: "zero_fresh",
        0x03: "cold_drink",
        0x04: "fresh_product",
        0x05: "partial_freezing",
        0x06: "dry_zone",
        0x07: "freeze_warm",
        0x08: "partial_freezing",
    }

    _humidity: ClassVar[dict[int, str]] = {
        0x10: "high",
        0x20: "low",
    }

    def __init__(
        self,
        *,
        customize: str,  # noqa: ARG002
        **kwargs: Unpack[MideaDeviceInitKwargs],
    ) -> None:
        """Initialize Midea CA device."""
        super().__init__(
            device_type=DeviceType.CA,
            **kwargs,
            attributes={
                # Read-only parser values; None means no general status received.
                DeviceAttributes.mode: None,
                DeviceAttributes.code_mode: None,
                DeviceAttributes.freezing_mode: None,
                DeviceAttributes.smart_mode: None,
                DeviceAttributes.energy_saving_mode: None,
                DeviceAttributes.holiday_mode: None,
                DeviceAttributes.moisturize_mode: None,
                DeviceAttributes.preservation_mode: None,
                DeviceAttributes.acme_freezing_mode: None,
                DeviceAttributes.flood_light: None,
                DeviceAttributes.freezing_ice_machine_power: None,
                DeviceAttributes.energy_consumption: None,
                DeviceAttributes.refrigerator_actual_temp: None,
                DeviceAttributes.freezer_actual_temp: None,
                DeviceAttributes.flex_zone_actual_temp: None,
                DeviceAttributes.right_flex_zone_actual_temp: None,
                DeviceAttributes.refrigerator_setting_temp: None,
                DeviceAttributes.freezer_setting_temp: None,
                DeviceAttributes.flex_zone_setting_temp: None,
                DeviceAttributes.right_flex_zone_setting_temp: None,
                DeviceAttributes.refrigerator_door_overtime: False,
                DeviceAttributes.freezer_door_overtime: False,
                DeviceAttributes.bar_door_overtime: False,
                DeviceAttributes.flex_zone_door_overtime: False,
                DeviceAttributes.refrigerator_door: False,
                DeviceAttributes.freezer_door: False,
                DeviceAttributes.bar_door: False,
                DeviceAttributes.flex_zone_door: False,
                DeviceAttributes.microcrystal_fresh: False,
                DeviceAttributes.electronic_smell: False,
                DeviceAttributes.humidity: None,
                DeviceAttributes.variable_mode: None,
            },
        )
        self._modes = [""]
        self._axfs = self.model == AXFS_MODEL and self.subtype == AXFS_SUBTYPE
        self._axfs_received = False
        if self._axfs:
            self._toshiba_protocol = True
            self._attributes = dict.fromkeys(AXFS_ATTRIBUTES)

    def build_query(self) -> list[MessageRequest]:
        """Midea CA device build query."""
        if self.toshiba_protocol:
            return self.build_toshiba_query()
        return [MessageQuery(self._message_protocol_version)]

    def process_message(self, msg: bytes) -> dict[str, Any]:
        """Midea CA device process message."""
        status = self.process_toshiba_message(msg)
        if status is not None:
            return status
        message = MessageCAResponse(msg)
        _LOGGER.debug("[%s] Received: %s", self.device_id, message)
        new_status = {}
        for attr in self._attributes:
            if hasattr(message, str(attr)):
                value = getattr(message, str(attr))
                # variable_mode
                if attr == DeviceAttributes.variable_mode:
                    self._attributes[attr] = MideaCADevice._variable_mode.get(value)
                # humidity
                elif attr == DeviceAttributes.humidity:
                    self._attributes[attr] = MideaCADevice._humidity.get(value)
                else:
                    self._attributes[attr] = value
                new_status[str(attr)] = self._attributes[attr]
        if (
            self.model == "310A2111"
            and self.subtype == SUBTYPE_310A2111
            and (
                DeviceAttributes.flex_zone_setting_temp in new_status
                or DeviceAttributes.variable_mode in new_status
            )
        ):
            # This model reports its preset through the setting temperature,
            # not the generic variable-mode byte. Emit the derived attribute
            # as well so consumers refresh on temperature-only updates.
            temperature = self._attributes[DeviceAttributes.flex_zone_setting_temp]
            mode = (
                FLEX_ZONE_MODE_BY_TEMPERATURE.get(temperature)
                if isinstance(temperature, (int, float))
                and not isinstance(temperature, bool)
                else None
            )
            self._attributes[DeviceAttributes.variable_mode] = mode
            new_status[DeviceAttributes.variable_mode] = mode
        return new_status

    def process_toshiba_frame(self, frame: ToshibaFrame) -> dict[str, Any] | None:
        """Decode and publish a Toshiba CA base status."""
        if self._axfs:
            status = decode_axfs_status(frame)
            if status is not None:
                self._axfs_received = True
        else:
            status = decode_toshiba_ca_status(
                frame,
                shifted=self.model == TOSHIBA_SHIFTED_MODEL,
            )
        if status is None:
            return None
        self._attributes.update(status)
        return dict(status)

    def set_attribute(self, attr: str, value: bool | float | str) -> None:
        """Midea CA device set attribute."""
        if not self._axfs:
            self.reject_toshiba_write()
            return
        if not self._axfs_received:
            raise ValueError("Read refrigerator status before changing settings")
        body = axfs_control_body(attr, value)
        self.build_send(
            ToshibaMessageRequest(
                self.device_type,
                self._message_protocol_version,
                body,
                frame_type=MessageType.set,
            ),
        )
        # Never publish optimistic state. Ask the appliance for actual readback.
        for query in self.build_query():
            self.build_send(query, query=True)


class MideaAppliance(MideaCADevice):
    """Midea CA appliance."""
